public class FlyNoWay implements FlyBehavior {
    public FlyNoWay() {}
    public void fly() {
        System.out.println("This duck can't fly");
    }
}
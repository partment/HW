public class FlyWithWings implements FlyBehavior {
    public FlyWithWings() {}
    public void fly() {
        System.out.println("This duck is flying with wings.");
    }
}
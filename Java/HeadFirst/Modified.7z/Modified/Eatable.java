public class Eatable implements EatStatus {
    public Eatable() {}
    public void eat() {
        System.out.println("You can eat this duck.");
    }
}
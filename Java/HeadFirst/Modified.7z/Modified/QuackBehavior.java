public interface QuackBehavior {
    void quack();
}
public interface EatStatus {
    void eat();
}
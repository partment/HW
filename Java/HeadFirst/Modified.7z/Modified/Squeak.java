public class Squeak implements QuackBehavior {
    public Squeak() {}
    public void quack() {
        System.out.println("This duck is squeaking.");
    }
}
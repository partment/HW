public class Quack implements QuackBehavior {
    public Quack() {}
    public void quack() {
        System.out.println("This duck is quacking.");
    }
}